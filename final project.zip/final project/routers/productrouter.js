const express = require("express")
const router = express.Router()
const products = require ('../controllers/productscontroller.js')
productRouter.get("/",products.getproducts);
productRouter.get("/:id", products.getproductsbyid);
productRouter.post("/", products.postproduct);
productRouter.put("/:id", products.updateproducts);
productRouter.delete("/:id", products.deleteproduct);

export default productRouter;

const dotenv = require("dotenv").config({path:"./connection/config.env"});
const express = require("express")
const app = express()
const port  = process.env.PORT ;
const mongoose = require ("mongoose"); 
const Router = require("./routers/productrouter")
app.use(express.json())
async function dbconnection (){
 try{
 await mongoose.connect(process.env.DB_URL)
 console.log("db connection sucess")
 }
 catch(err){
    console.log(err);
 }
}
dbconnection ()

app.listen(port ,()=>{
    console.log(`server is running in port at ${port}`)
})